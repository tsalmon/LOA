#include "Jeu.hpp"
#include "Partie.hpp"

int Jeu::getNbLignes(){
  return nbLignes;
}
int Jeu::getNbJoueur(){
  return nbJoueur;
}
int Jeu::getNbColonnes(){
  return nbColonnes;
}

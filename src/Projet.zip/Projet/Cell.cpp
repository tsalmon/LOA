//
//  Cell.cpp
//  Projet
//
//  Created by Владислав Фиц on 18.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#include "Cell.h"
Cell::Cell(unsigned int x, unsigned int y, Checker *ch){
    this->coordinateX = x;
    this->coordinateY = y;
    this->nestedChecker = ch;
}
/*
void Cell::operator=(Cell &c){
    this->coordinateX = c.getX();
    this->coordinateY = c.getY();
    this->nestedChecker = c.getChecker();
}*/

Checker *Cell::getChecker() const{
    return this->nestedChecker;
}

void Cell::placeChecker(Checker &ch){
    this->nestedChecker = &ch;
}

void Cell::removeChecker(){
    this->nestedChecker = NULL;
}

unsigned int Cell::getX(){
    return this->coordinateX;
}

unsigned int Cell::getY(){
    return this->coordinateY;
}
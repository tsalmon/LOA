//
//  main.cpp
//  Projet
//
//  Created by Владислав Фиц on 16.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#include <iostream>
#include "CheckerFactory.h"
#include "Board.h"

int main(int argc, const char * argv[])
{
    Checker b = *CheckerFactory::getInstance().getChecker("black");
    Checker a = *CheckerFactory::getInstance().getChecker("white");
    Checker c = *CheckerFactory::getInstance().getChecker("black");
    Board brd(5,5);
    cout << brd << endl;
    brd.placeCheckerToCell(a, 1, 1);
    
}



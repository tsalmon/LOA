//
//  Cell.h
//  Projet
//
//  Created by Владислав Фиц on 18.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#ifndef __Projet__Cell__
#define __Projet__Cell__

#include <iostream>
#include "Checker.h"

class Cell{
private:
    unsigned int coordinateX;
    unsigned int coordinateY;
    Checker *nestedChecker;
public:
    Cell(unsigned int x, unsigned int y, Checker *ch=NULL);
    Checker *getChecker() const;
    void placeChecker(Checker &ch);
    void removeChecker();
    unsigned int getX();
    unsigned int getY();
};
#endif /* defined(__Projet__Cell__) */

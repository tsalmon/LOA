//
//  Checker.h
//  Projet
//
//  Created by Владислав Фиц on 16.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#ifndef __Projet__Checker__
#define __Projet__Checker__

#include <iostream>
using namespace std;
class Checker{
private:
    string name;
    Checker(string name="nope");
    friend class CheckerFactory;
public:

};


#endif /* defined(__Projet__Checker__) */

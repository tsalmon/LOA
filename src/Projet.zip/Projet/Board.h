//
//  Board.h
//  Projet
//
//  Created by Владислав Фиц on 16.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#ifndef __Projet__Board__
#define __Projet__Board__

#include <iostream>
#include <vector>
#include "Cell.h"
using namespace std;
class Board{
private:
    vector< std::vector<Cell> > matrix;
    unsigned int rows;
    unsigned int columns;
public:
    Board(unsigned int, unsigned int);
    void placeCheckerToCell(Checker &checker, unsigned int x, unsigned int y);
    void removeCheckerOnCell(unsigned int x, unsigned y);
    Checker *checkerOnCell(unsigned int x, unsigned int y);
    friend ostream &operator<<(ostream &,const Board &);
};


#endif /* defined(__Projet__Board__) */

//
//  Checker.cpp
//  Projet
//
//  Created by Владислав Фиц on 16.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#include "Checker.h"


Checker::Checker(string name){
    this->name = name;
}
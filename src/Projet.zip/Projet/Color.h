//
//  Color.h
//  Projet
//
//  Created by Владислав Фиц on 16.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#ifndef __Projet__Color__
#define __Projet__Color__

#include <iostream>
#include <vector>
using namespace std;

class Color {
private:
    unsigned int red;
    unsigned int green;
    unsigned int blue;
    static vector<Color> existingColors;
public:
    Color(unsigned int red = 0, unsigned int green = 0, unsigned int blue = 0);
    static Color &getColor(unsigned int red, unsigned int green, unsigned int blue);
    static Color white;
    static Color black;
};

#endif /* defined(__Projet__Color__) */

//
//  Board.cpp
//  Projet
//
//  Created by Владислав Фиц on 16.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#include "Board.h"

Board::Board(unsigned int c, unsigned int r){
    for(int i = 0; i<r; ++i){
        for (int j = 0; j<c; ++j) {
            Cell c(1,2);
            vector<Cell> row(c);
            this->matrix.push_back(Cell(i,j));
            //this->matrix[i][j] = Cell(i, j);
        }
    }
}

void Board::placeCheckerToCell(Checker &checker, unsigned int x, unsigned int y){
    this->matrix[x][y].placeChecker(checker);
}

Checker *Board::checkerOnCell(unsigned int x, unsigned int y){
    return this->matrix[x][y].getChecker();
}

void Board::removeCheckerOnCell(unsigned int x, unsigned y){
    this->matrix[x][y].removeChecker();
}

ostream &operator<<(ostream &os,const Board &b) {
    for (int i = 0; i<b.columns; ++i) {
        os << "–";
    }
    os << endl;
    
    for(int i = 0; i<b.rows; ++i){
        for (int j = 0; i<b.columns; ++i) {
            if(!b.matrix[i][j].getChecker())
            {
                os << "☐ ";
            } else {
                os << "◉ ";
            }
        }
        os<<endl;;
    }
    for (int i = 0; i<b.columns; ++i) {
        os << "–";
    }
    os << endl;
    return os;
}
//
//  Color.cpp
//  Projet
//
//  Created by Владислав Фиц on 16.01.14.
//  Copyright (c) 2014 Vladislav Fitc. All rights reserved.
//

#include "Color.h"
Color::Color(unsigned int red, unsigned int green, unsigned int blue){
    this->red = red;
    this->green = green;
    this->blue = blue;
}
    /*
Color &Color::getColor(unsigned int red, unsigned int green, unsigned int blue){

    for (int i=0; i<Color::existingColorsCount; ++i) {
        if (Color::existingColors[i].red == red &&
            Color::existingColors[i].green == green &&
            Color::existingColors[i].blue == blue){
            return Color::existingColors[i];
        }
    }
    vector<Color>::iterator it = Color::existingColors.begin();
    it+=Color::existingColorsCount-1;
    Color c = Color(red, green, blue);
    Color::existingColors.insert(it, c);
    Color::existingColorsCount++;
    return Color::existingColors[existingColorsCount-1];
}*/
